from django.apps import AppConfig


class SentimentClassifyConfig(AppConfig):
    name = 'sentiment_classify'
